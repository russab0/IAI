?- start(possible).
?- start(impossible).
?- start(without_pits).
